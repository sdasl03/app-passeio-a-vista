package mz.uab.passeioavista.auth;

import android.content.*;import android.net.Uri;

public class OAuthManager {
    private static final String CLIENT_ID="SUBSTITUIR_PELO_CLIENT_ID_GOOGLE";
    private static final String REDIRECT="passeioavista://oauth2redirect";
    public static void startGoogleLogin(Context c){
        Uri uri = Uri.parse("https://accounts.google.com/o/oauth2/v2/auth")
                .buildUpon().appendQueryParameter("client_id", CLIENT_ID)
                .appendQueryParameter("redirect_uri", REDIRECT)
                .appendQueryParameter("response_type", "code")
                .appendQueryParameter("scope", "openid email profile")
                .appendQueryParameter("prompt", "select_account")
                .build();
        c.startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }
}
