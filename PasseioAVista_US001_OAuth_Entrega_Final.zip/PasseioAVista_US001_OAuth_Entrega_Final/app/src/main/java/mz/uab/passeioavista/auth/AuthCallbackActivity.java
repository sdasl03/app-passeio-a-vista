package mz.uab.passeioavista.auth;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import mz.uab.passeioavista.MainActivity;

public class AuthCallbackActivity extends Activity {
    protected void onCreate(Bundle b){ super.onCreate(b); Uri data=getIntent().getData();
        if(data!=null && data.getQueryParameter("code")!=null){
            // Protótipo académico: em produção, enviar o code ao backend para trocar por token.
            SessionManager.login(this,"Turista OAuth","turista.oauth@passeioavista.mz", data.getQueryParameter("code"));
        }
        Intent i=new Intent(this, MainActivity.class); i.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); finish();
    }
}
