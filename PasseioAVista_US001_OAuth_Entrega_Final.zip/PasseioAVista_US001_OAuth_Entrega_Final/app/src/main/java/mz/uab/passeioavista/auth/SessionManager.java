package mz.uab.passeioavista.auth;

import android.content.*;

public class SessionManager {
    private static final String PREF="auth_session";
    public static void login(Context c, String name, String email, String token){ c.getSharedPreferences(PREF,0).edit().putBoolean("logged",true).putString("name",name).putString("email",email).putString("token",token).apply(); }
    public static void logout(Context c){ c.getSharedPreferences(PREF,0).edit().clear().apply(); }
    public static boolean isLogged(Context c){ return c.getSharedPreferences(PREF,0).getBoolean("logged", false); }
    public static String name(Context c){ return c.getSharedPreferences(PREF,0).getString("name","Utilizador autenticado"); }
    public static String email(Context c){ return c.getSharedPreferences(PREF,0).getString("email","utilizador@exemplo.com"); }
}
