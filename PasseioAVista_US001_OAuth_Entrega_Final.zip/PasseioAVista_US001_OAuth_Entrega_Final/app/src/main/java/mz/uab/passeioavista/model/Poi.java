package mz.uab.passeioavista.model;

public class Poi {
    public final String name, category, description, hours, price, accessibility, distance;
    public Poi(String name, String category, String description, String hours, String price, String accessibility, String distance) {
        this.name=name; this.category=category; this.description=description; this.hours=hours; this.price=price; this.accessibility=accessibility; this.distance=distance;
    }
}
