@echo off
REM Open in Android Studio or run: gradle wrapper --gradle-version 8.7
gradle %*
