package mz.uab.passeioavista;

import android.app.*;import android.os.*;import android.view.*;import android.widget.*;import android.content.*;import java.util.*;
import mz.uab.passeioavista.auth.*;import mz.uab.passeioavista.data.PoiRepository;import mz.uab.passeioavista.model.Poi;import mz.uab.passeioavista.ui.PoiDetailActivity;

public class MainActivity extends Activity {
    TextView txtSession; Button btnLogin, btnLogout; LinearLayout poiContainer;
    protected void onCreate(Bundle b){ super.onCreate(b); setContentView(getResources().getIdentifier("activity_main","layout",getPackageName()));
        txtSession=findViewById(getResources().getIdentifier("txtSession","id",getPackageName())); btnLogin=findViewById(getResources().getIdentifier("btnLogin","id",getPackageName())); btnLogout=findViewById(getResources().getIdentifier("btnLogout","id",getPackageName())); poiContainer=findViewById(getResources().getIdentifier("poiContainer","id",getPackageName()));
        btnLogin.setOnClickListener(v -> OAuthManager.startGoogleLogin(this)); btnLogout.setOnClickListener(v -> {SessionManager.logout(this); refresh();}); renderPois(); refresh(); }
    void refresh(){ boolean logged=SessionManager.isLogged(this); btnLogin.setVisibility(logged?View.GONE:View.VISIBLE); btnLogout.setVisibility(logged?View.VISIBLE:View.GONE); txtSession.setText(logged?"Sessão ativa: "+SessionManager.name(this)+" — "+SessionManager.email(this):"Modo visitante: autentique-se para favoritos, comentários e roteiros."); }
    void renderPois(){ poiContainer.removeAllViews(); for(Poi p: PoiRepository.all()){ TextView card=new TextView(this); card.setText("• "+p.name+"\n"+p.category+" | "+p.distance+"\n"+p.description+"\n\nTocar para detalhes"); card.setTextSize(16); card.setPadding(22,22,22,22); card.setBackgroundResource(getResources().getIdentifier("card_bg","drawable",getPackageName())); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,12,0,12); card.setLayoutParams(lp); card.setOnClickListener(v -> { Intent i=new Intent(this, PoiDetailActivity.class); i.putExtra("name",p.name); i.putExtra("info",p.category+"\n"+p.description+"\nHorário: "+p.hours+"\nPreço: "+p.price+"\nAcessibilidade: "+p.accessibility+"\nDistância: "+p.distance); startActivity(i);}); poiContainer.addView(card);} }
}
