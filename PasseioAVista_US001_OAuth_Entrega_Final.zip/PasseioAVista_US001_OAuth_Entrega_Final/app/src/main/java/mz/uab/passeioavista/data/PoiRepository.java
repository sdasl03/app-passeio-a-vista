package mz.uab.passeioavista.data;

import java.util.*;
import mz.uab.passeioavista.model.Poi;

public class PoiRepository {
    public static List<Poi> all() {
        List<Poi> items = new ArrayList<>();
        items.add(new Poi("Fortaleza de Maputo", "História", "Monumento histórico recomendado para visitantes interessados na memória urbana de Maputo.", "08:00–17:00", "Entrada simbólica", "Acesso parcial", "2,1 km"));
        items.add(new Poi("FEIMA", "Cultura e Artesanato", "Espaço de artesanato, gastronomia local e contacto cultural.", "09:00–18:00", "Gratuito", "Acesso fácil", "3,4 km"));
        items.add(new Poi("Praia da Costa do Sol", "Lazer", "Zona costeira indicada para descanso, fotografia e gastronomia.", "Aberto", "Gratuito", "Acesso fácil", "8,7 km"));
        items.add(new Poi("Museu de História Natural", "Museu", "Espaço educativo com exposições sobre biodiversidade e história natural.", "09:00–15:30", "Bilhete local", "Acesso parcial", "1,5 km"));
        items.add(new Poi("Jardim dos Professores", "Lazer urbano", "Local de passeio urbano, descanso e convivência.", "Aberto", "Gratuito", "Acesso fácil", "900 m"));
        return items;
    }
}
