# Checklist de Entrega

- [x] Estrutura de projeto Android.
- [x] Manifest com permissões e deep link OAuth.
- [x] MainActivity com tela inicial e POIs.
- [x] OAuthManager com abertura de browser.
- [x] AuthCallbackActivity para retorno OAuth.
- [x] SessionManager para sessão do protótipo.
- [x] Tela de detalhe de ponto de interesse.
- [x] Documentação da US001.
- [x] Diagramas PlantUML.
- [x] Mockups das telas.
- [ ] Substituir Client ID Google antes de usar em produção.
- [ ] Gerar gradle-wrapper.jar oficial pelo Android Studio/Gradle.
