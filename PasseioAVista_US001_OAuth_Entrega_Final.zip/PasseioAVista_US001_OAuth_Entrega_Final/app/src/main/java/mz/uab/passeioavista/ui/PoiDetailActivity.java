package mz.uab.passeioavista.ui;

import android.app.*;import android.os.*;import android.widget.*;import mz.uab.passeioavista.auth.SessionManager;

public class PoiDetailActivity extends Activity {
 protected void onCreate(Bundle b){ super.onCreate(b); setContentView(getResources().getIdentifier("activity_poi_detail","layout",getPackageName()));
  TextView title=findViewById(getResources().getIdentifier("txtTitle","id",getPackageName())); TextView info=findViewById(getResources().getIdentifier("txtInfo","id",getPackageName())); Button fav=findViewById(getResources().getIdentifier("btnFavorite","id",getPackageName()));
  title.setText(getIntent().getStringExtra("name")); info.setText(getIntent().getStringExtra("info"));
  fav.setOnClickListener(v -> Toast.makeText(this, SessionManager.isLogged(this)?"Ponto guardado nos favoritos.":"Faça login para guardar favoritos.", Toast.LENGTH_LONG).show());
 }
}
