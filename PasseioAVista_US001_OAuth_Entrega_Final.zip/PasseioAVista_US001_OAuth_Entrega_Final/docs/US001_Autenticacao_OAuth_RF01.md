# US001 — Autenticação OAuth (RF01)

**Story Points:** 5 SP  
**Tema:** App de Turismo com Pontos de Interesse Contextualizados

## 1. User Story
Como utilizador da aplicação de turismo, quero autenticar-me através de uma conta externa, como Google, para aceder de forma rápida e segura às funcionalidades personalizadas da aplicação.

## 2. Objetivo
Permitir login seguro sem armazenamento local de palavras-passe, associando o utilizador a favoritos, comentários, avaliações e roteiros turísticos.

## 3. Funcionalidades implementadas
- Botão “Entrar com Google OAuth”.
- Abertura do browser com endpoint OAuth.
- Redirect URI por deep link: `passeioavista://oauth2redirect`.
- Activity de callback para receber o código de autorização.
- Gestão de sessão local para o protótipo académico.
- Logout seguro.
- Bloqueio de favoritos para utilizador não autenticado.
- Lista contextualizada de pontos de interesse.

## 4. Regras de negócio
| Código | Regra |
|---|---|
| RN01 | A app não deve armazenar palavras-passe. |
| RN02 | O login deve ocorrer no provedor externo. |
| RN03 | O utilizador autenticado pode guardar favoritos. |
| RN04 | O utilizador visitante pode consultar pontos públicos. |
| RN05 | O logout deve remover a sessão local. |

## 5. Critérios de aceitação
| Critério | Resultado esperado |
|---|---|
| Clicar em Entrar com Google | Browser abre o fluxo OAuth. |
| Login autorizado | App recebe o retorno por deep link. |
| Sessão ativa | Nome e email são apresentados. |
| Favorito sem login | App solicita autenticação. |
| Favorito com login | App confirma gravação do favorito. |
| Logout | Sessão é removida. |

## 6. Estimativa — 5 SP
A estimativa de 5 Story Points justifica-se por envolver integração com provedor externo, browser, deep link, validação de retorno, gestão de sessão, segurança e tratamento de fluxos alternativos.
