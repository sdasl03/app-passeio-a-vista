# Passeio à Vista — US001 Autenticação OAuth (RF01)

Tema: App de Turismo com Pontos de Interesse Contextualizados

Esta pasta contém um protótipo Android nativo em Java para a funcionalidade US001 — Autenticação OAuth, com fluxo de login via browser, retorno por deep link, gestão de sessão, lista de pontos de interesse e bloqueio de favoritos para utilizadores não autenticados.

## Como abrir
1. Abrir o Android Studio.
2. Selecionar **Open**.
3. Escolher a pasta `PasseioAVista_US001_OAuth_Entrega_Final`.
4. Aguardar o Gradle Sync.

## Nota técnica importante
O ficheiro `gradle-wrapper.jar` não foi incluído porque deve ser gerado pelo próprio Gradle/Android Studio para evitar wrapper inválido. Caso o Android Studio solicite, executar:

```bash
gradle wrapper --gradle-version 8.7
```

Depois disso, a pasta `gradle/wrapper` ficará completa com o JAR oficial.

## OAuth
O projeto está preparado para OAuth com Google. Para funcionar com uma conta real, deve-se substituir `SUBSTITUIR_PELO_CLIENT_ID_GOOGLE` pelo Client ID gerado no Google Cloud Console e configurar o redirect URI:

`passeioavista://oauth2redirect`

Em ambiente de produção, o `code` recebido deve ser enviado ao backend para troca por token e validação segura.
